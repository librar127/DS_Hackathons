#!/usr/bin/env python
# coding: utf-8

# In[1]:


import matplotlib.pyplot as plt
import numpy as np 
import pandas as pd
import matplotlib


# In[ ]:


matplotlib.rcParams.update({'font.size': 12})
from sklearn.datasets import load_boston
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.linear_model import Ridge

import xgboost as xgb
from sklearn.model_selection import train_test_split, cross_val_score, KFold
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import RandomizedSearchCV
from sklearn.preprocessing import StandardScaler



import numpy as np
from sklearn.svm import SVR
import matplotlib.pyplot as plt

# #############################################################################

def save_prediction_to_csv(y_pred):
    """
    Use this function to save your prediction result to a csv file.
    The resulting csv file is named as [team_name].csv

    :param y_pred: an array or a pandas series that follows the SAME index order as in the testing data
    """
    pd.DataFrame(dict(
        target=y_pred
    )).to_csv('predictions.csv', index=False, header=False)

# #############################################################################

 #### Read Train and Test Data
training_data = pd.read_csv('/home/rajneesh/Desktop/Queen_City_Hackathon/training.csv', index_col=0)
testing_data = pd.read_csv('/home/rajneesh/Desktop/Queen_City_Hackathon/testing.csv', index_col=0)

### Check for the co relared columns 

# Create correlation matrix
corr_matrix = training_data.corr().abs()

# Select upper triangle of correlation matrix
upper = corr_matrix.where(np.triu(np.ones(corr_matrix.shape), k=1).astype(np.bool))

# Find index of feature columns with correlation greater than 0.95
columns_to_drop = [column for column in upper.columns if any(upper[column] > 0.85)]

### Drop all the co-related columns
data_nodups_df = training_data.drop(columns=columns_to_drop)


#### Data Preparation
data_nonull_df = data_nodups_df.fillna(data_nodups_df.mean())

y = training_data['target']
X = data_nonull_df.drop(columns=['target'])


# In[19]:


from sklearn.ensemble import RandomForestRegressor
regr = RandomForestRegressor(max_depth=5, random_state=0, n_estimators=100)
regr.fit(X, y)


# In[20]:


test_nodups_df = testing_data.drop(columns=columns_to_drop)
test_nonull_df = test_nodups_df.fillna(data_nodups_df.mean())


# In[21]:


#regr.predict(test_nonull_df).sum()
save_prediction_to_csv(regr.predict(test_nonull_df))
