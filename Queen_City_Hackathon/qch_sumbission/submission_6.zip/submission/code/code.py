import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

import xgboost as xgb
from catboost import CatBoostRegressor
import pandas.util.testing as tm
pd.set_option('display.max_rows', 500)
pd.set_option('display.max_columns', 500)
pd.set_option('display.width', 500)

from sklearn.model_selection import train_test_split, cross_val_score, KFold
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import RandomizedSearchCV


def save_prediction_to_csv(y_pred):
    """
    Use this function to save your prediction result to a csv file.
    The resulting csv file is named as [team_name].csv

    :param y_pred: an array or a pandas series that follows the SAME index order as in the testing data
    """
    pd.DataFrame(dict(
        target=y_pred
    )).to_csv('predictions.csv', index=False, header=False)
 
  #### Read Train and Test Data
training_data = pd.read_csv('/home/rajneesh/Desktop/Queen_City_Hackathon/training.csv', index_col=0)
testing_data = pd.read_csv('/home/rajneesh/Desktop/Queen_City_Hackathon/testing.csv', index_col=0)

### Check for the co relared columns 

# Create correlation matrix
# Create correlation matrix
corr_matrix = training_data.corr().abs()

# Select upper triangle of correlation matrix
upper = corr_matrix.where(np.triu(np.ones(corr_matrix.shape), k=1).astype(np.bool))

# Find index of feature columns with correlation greater than 0.95
columns_to_drop = [column for column in upper.columns if any(upper[column] > 0.92)]


### Drop all the co-related columns
data_nodups_df = training_data.drop(columns=columns_to_drop)


#### Data Preparation
data_nonull_df = data_nodups_df.fillna(data_nodups_df.mean())

y = data_nonull_df['target']
X = data_nodups_df.drop(columns=['target'])

X_train, X_validation, y_train, y_validation = train_test_split(X, y, train_size=0.7, random_state=1234)

from catboost import CatBoostRegressor
model=CatBoostRegressor()
model.fit(X_train, y_train, eval_set=(X_validation, y_validation), plot=True, early_stopping_rounds=20)

### Predict on test dataset
#### Drop same column which has been dropped in training set
test_nodups_df = testing_data.drop(columns=columns_to_drop)
#### Fill missing values by the values which are used during the training data
test_nodups_df = test_nodups_df.fillna(data_nodups_df.mean())

### Convert into DMAtrix and predict
predictions = model.predict(test_nodups_df)

save_prediction_to_csv(predictions)