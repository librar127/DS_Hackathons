#!/usr/bin/env python
# coding: utf-8

# In[1]:


import matplotlib.pyplot as plt
import numpy as np 
import pandas as pd
import matplotlib


# In[58]:


matplotlib.rcParams.update({'font.size': 12})
from sklearn.datasets import load_boston
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.linear_model import Ridge

import xgboost as xgb
from sklearn.model_selection import train_test_split, cross_val_score, KFold
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import RandomizedSearchCV


# In[74]:


#### Read Train and Test Data
training_data = pd.read_csv('/home/rajneesh/Desktop/Queen_City_Hackathon/training.csv', index_col=0)
testing_data = pd.read_csv('/home/rajneesh/Desktop/Queen_City_Hackathon/testing.csv', index_col=0)

### Check for the co relared columns 

# Create correlation matrix
# Create correlation matrix
corr_matrix = training_data.corr().abs()

# Select upper triangle of correlation matrix
upper = corr_matrix.where(np.triu(np.ones(corr_matrix.shape), k=1).astype(np.bool))

# Find index of feature columns with correlation greater than 0.95
columns_to_drop = [column for column in upper.columns if any(upper[column] > 0.95)]


### Drop all the co-related columns
data_nodups_df = training_data.drop(columns=columns_to_drop)
data_nonull_df = data_nodups_df.fillna(data_nodups_df.mean())
y = data_nonull_df['target']
X = data_nonull_df.drop(columns=['target'])


# In[75]:


from sklearn.decomposition import PCA
pca = PCA(n_components=50)
pca_data = pca.fit_transform(X)
pca.explained_variance_ratio_.cumsum()


# In[77]:


X_train, X_test, y_train, y_test=train_test_split(pca_data, y, test_size=0.30)


# In[78]:


best_params = {"objective":"reg:squarederror", 'subsample': 0.95, 'reg_lambda': 1e-05, 'reg_alpha': 1e-05, 'n_estimators': 300, 'min_child_weight': 1.5, 'max_depth': 7, 'learning_rate': 0.07, 'gamma': 0.03, 'colsample_bytree': 0.4}

train_dmatrix = xgb.DMatrix(data=X_train, label=y_train)
xg_reg = xgb.train(params=best_params, dtrain=train_dmatrix, num_boost_round=1000)


# In[79]:


y_pred = xg_reg.predict(xgb.DMatrix(data=X_test))


# In[80]:


mse = mean_squared_error(y_test, y_pred)
print("MSE: %.2f" % mse)
print("RMSE: %.2f" % np.sqrt(mse))


# In[81]:


xg_reg = xgb.train(params=best_params, dtrain=xgb.DMatrix(data=pca_data, label=y), num_boost_round=1000)


# In[85]:


test_nodups_df = testing_data.drop(columns=columns_to_drop)
test_nodups_df = test_nodups_df.fillna(data_nodups_df.mean())

pca_test = pca.transform(test_nodups_df)


# In[88]:


y_pred = xg_reg.predict(xgb.DMatrix(data=pca_test))


# In[87]:


def save_prediction_to_csv(y_pred):
    """
    Use this function to save your prediction result to a csv file.
    The resulting csv file is named as [team_name].csv

    :param y_pred: an array or a pandas series that follows the SAME index order as in the testing data
    """
    pd.DataFrame(dict(
        target=y_pred
    )).to_csv('predictions.csv', index=False, header=False)


# In[90]:


save_prediction_to_csv(y_pred)


# In[ ]:




